package com.rikaz.app;
import android.app.Activity; import android.os.Bundle; import android.webkit.*;
public class MainActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b); WebView w=new WebView(this); w.setWebViewClient(new WebViewClient()); w.setWebChromeClient(new WebChromeClient()); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); w.loadUrl("file:///android_asset/index.html"); setContentView(w);}
}
